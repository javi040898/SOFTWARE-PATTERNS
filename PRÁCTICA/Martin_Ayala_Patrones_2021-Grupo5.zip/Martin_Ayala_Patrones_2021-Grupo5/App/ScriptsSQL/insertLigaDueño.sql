INSERT INTO "Liga" VALUES(1,'Estados Unidos','Primera');

--Ejecutar lo siguiente, una vez se introduzcan los equipos
INSERT INTO "Dueño" VALUES('94567315R','Jerry','Buss','Estados Unidos','jerrybuss@gmail.com',1,'1453');
INSERT INTO "Dueño" VALUES('45648315S','Steve','Ballmer','Estados Unidos','steveballmer@gmail.com',2,'4454');
INSERT INTO "Dueño" VALUES('91741234F','Joseph','Tsai','Estados Unidos','josephtsai@gmail.com',3,'5450');
INSERT INTO "Dueño" VALUES('13568315R','Wes','Edens','Estados Unidos','wesedens@gmail.com',4,'6457');
INSERT INTO "Dueño" VALUES('57896455D','Logan','Williams','Estados Unidos','LoganWilliams@gmail.com',5,'7455');
INSERT INTO "Dueño" VALUES('14789655L','Jerry','Reinsdorf','Estados Unidos','JerryReinsdorf@gmail.com',6,'8455');

select * from "Dueño"

